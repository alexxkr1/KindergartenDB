﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TARge20.Data.Migrations
{
    public partial class Kindergarten : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Kindergartens",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Kindergartens", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Kitchen",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Kitchen", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Queues",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    QueuePosition = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Queues", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "WorkingHistory",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Start = table.Column<DateTime>(nullable: false),
                    End = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WorkingHistory", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "GetCooks",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    FirstName = table.Column<string>(nullable: true),
                    Lastname = table.Column<string>(nullable: true),
                    Birthday = table.Column<DateTime>(nullable: false),
                    KitchenId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GetCooks", x => x.Id);
                    table.ForeignKey(
                        name: "FK_GetCooks_Kitchen_KitchenId",
                        column: x => x.KitchenId,
                        principalTable: "Kitchen",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Menus",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Meal = table.Column<string>(nullable: true),
                    Drink = table.Column<string>(nullable: true),
                    Dessert = table.Column<string>(nullable: true),
                    Date = table.Column<DateTime>(nullable: false),
                    KitchenId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Menus", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Menus_Kitchen_KitchenId",
                        column: x => x.KitchenId,
                        principalTable: "Kitchen",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Groups",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    GroupType = table.Column<string>(nullable: true),
                    KindergartenId = table.Column<Guid>(nullable: true),
                    QueueId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Groups", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Groups_Kindergartens_KindergartenId",
                        column: x => x.KindergartenId,
                        principalTable: "Kindergartens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Groups_Queues_QueueId",
                        column: x => x.QueueId,
                        principalTable: "Queues",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Childrens",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    Birthday = table.Column<DateTime>(nullable: false),
                    GroupId = table.Column<Guid>(nullable: true),
                    KindergartenId = table.Column<Guid>(nullable: true),
                    QueueId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Childrens", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Childrens_Groups_GroupId",
                        column: x => x.GroupId,
                        principalTable: "Groups",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Childrens_Kindergartens_KindergartenId",
                        column: x => x.KindergartenId,
                        principalTable: "Kindergartens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Childrens_Queues_QueueId",
                        column: x => x.QueueId,
                        principalTable: "Queues",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "EatingHistories",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Meal = table.Column<string>(nullable: true),
                    Drink = table.Column<string>(nullable: true),
                    Dessert = table.Column<string>(nullable: true),
                    GroupId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EatingHistories", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EatingHistories_Groups_GroupId",
                        column: x => x.GroupId,
                        principalTable: "Groups",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Educators",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    GroupId = table.Column<Guid>(nullable: true),
                    KindergartenId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Educators", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Educators_Groups_GroupId",
                        column: x => x.GroupId,
                        principalTable: "Groups",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Educators_Kindergartens_KindergartenId",
                        column: x => x.KindergartenId,
                        principalTable: "Kindergartens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Absences",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Date = table.Column<DateTime>(nullable: false),
                    reason = table.Column<string>(nullable: true),
                    ChildrenId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Absences", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Absences_Childrens_ChildrenId",
                        column: x => x.ChildrenId,
                        principalTable: "Childrens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "GroupHistories",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Start = table.Column<DateTime>(nullable: false),
                    End = table.Column<DateTime>(nullable: false),
                    ChildrenId = table.Column<Guid>(nullable: true),
                    GroupId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GroupHistories", x => x.Id);
                    table.ForeignKey(
                        name: "FK_GroupHistories_Childrens_ChildrenId",
                        column: x => x.ChildrenId,
                        principalTable: "Childrens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_GroupHistories_Groups_GroupId",
                        column: x => x.GroupId,
                        principalTable: "Groups",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Parents",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    MumName = table.Column<string>(nullable: true),
                    DadName = table.Column<string>(nullable: true),
                    MumPhone = table.Column<int>(nullable: false),
                    DadPhone = table.Column<int>(nullable: false),
                    ChildrenId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Parents", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Parents_Childrens_ChildrenId",
                        column: x => x.ChildrenId,
                        principalTable: "Childrens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Positions",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    PositionType = table.Column<string>(nullable: true),
                    PositionName = table.Column<string>(nullable: true),
                    CookId = table.Column<Guid>(nullable: true),
                    EducatorId = table.Column<Guid>(nullable: true),
                    WorkingHistoryId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Positions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Positions_GetCooks_CookId",
                        column: x => x.CookId,
                        principalTable: "GetCooks",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Positions_Educators_EducatorId",
                        column: x => x.EducatorId,
                        principalTable: "Educators",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Positions_WorkingHistory_WorkingHistoryId",
                        column: x => x.WorkingHistoryId,
                        principalTable: "WorkingHistory",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Absences_ChildrenId",
                table: "Absences",
                column: "ChildrenId");

            migrationBuilder.CreateIndex(
                name: "IX_Childrens_GroupId",
                table: "Childrens",
                column: "GroupId");

            migrationBuilder.CreateIndex(
                name: "IX_Childrens_KindergartenId",
                table: "Childrens",
                column: "KindergartenId");

            migrationBuilder.CreateIndex(
                name: "IX_Childrens_QueueId",
                table: "Childrens",
                column: "QueueId");

            migrationBuilder.CreateIndex(
                name: "IX_EatingHistories_GroupId",
                table: "EatingHistories",
                column: "GroupId");

            migrationBuilder.CreateIndex(
                name: "IX_Educators_GroupId",
                table: "Educators",
                column: "GroupId");

            migrationBuilder.CreateIndex(
                name: "IX_Educators_KindergartenId",
                table: "Educators",
                column: "KindergartenId");

            migrationBuilder.CreateIndex(
                name: "IX_GetCooks_KitchenId",
                table: "GetCooks",
                column: "KitchenId");

            migrationBuilder.CreateIndex(
                name: "IX_GroupHistories_ChildrenId",
                table: "GroupHistories",
                column: "ChildrenId");

            migrationBuilder.CreateIndex(
                name: "IX_GroupHistories_GroupId",
                table: "GroupHistories",
                column: "GroupId");

            migrationBuilder.CreateIndex(
                name: "IX_Groups_KindergartenId",
                table: "Groups",
                column: "KindergartenId");

            migrationBuilder.CreateIndex(
                name: "IX_Groups_QueueId",
                table: "Groups",
                column: "QueueId");

            migrationBuilder.CreateIndex(
                name: "IX_Menus_KitchenId",
                table: "Menus",
                column: "KitchenId");

            migrationBuilder.CreateIndex(
                name: "IX_Parents_ChildrenId",
                table: "Parents",
                column: "ChildrenId");

            migrationBuilder.CreateIndex(
                name: "IX_Positions_CookId",
                table: "Positions",
                column: "CookId");

            migrationBuilder.CreateIndex(
                name: "IX_Positions_EducatorId",
                table: "Positions",
                column: "EducatorId");

            migrationBuilder.CreateIndex(
                name: "IX_Positions_WorkingHistoryId",
                table: "Positions",
                column: "WorkingHistoryId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Absences");

            migrationBuilder.DropTable(
                name: "EatingHistories");

            migrationBuilder.DropTable(
                name: "GroupHistories");

            migrationBuilder.DropTable(
                name: "Menus");

            migrationBuilder.DropTable(
                name: "Parents");

            migrationBuilder.DropTable(
                name: "Positions");

            migrationBuilder.DropTable(
                name: "Childrens");

            migrationBuilder.DropTable(
                name: "GetCooks");

            migrationBuilder.DropTable(
                name: "Educators");

            migrationBuilder.DropTable(
                name: "WorkingHistory");

            migrationBuilder.DropTable(
                name: "Kitchen");

            migrationBuilder.DropTable(
                name: "Groups");

            migrationBuilder.DropTable(
                name: "Kindergartens");

            migrationBuilder.DropTable(
                name: "Queues");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Group
    {
        [Key]
        public Guid Id { get; set; }
        public string GroupType { get; set; }
        public IEnumerable<EatingHistory> EatingHistories { get; set; } = new List<EatingHistory>();

        public IEnumerable<Children> Childrens { get; set; } = new List<Children>();
        public IEnumerable<Educator> Educators { get; set; } = new List<Educator>();
        public IEnumerable<GroupHistory> GroupHistories { get; set; } = new List<GroupHistory>();
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Cook
    {
        [Key]
        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string Lastname { get; set; }
        public DateTime Birthday { get; set; }
        public IEnumerable<Position> Positions { get; set; } = new List<Position>();
    }
}



﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Children
    {
        [Key]
        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime Birthday { get; set; }
        public IEnumerable<GroupHistory> GroupHistories { get; set; } = new List<GroupHistory>();
        public IEnumerable<Absence> Absences { get; set; } = new List<Absence>();
        public IEnumerable<Parent> Parents { get; set; } = new List<Parent>();

    }
}
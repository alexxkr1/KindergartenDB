﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Queue
    {
        [Key]
        public Guid Id { get; set; }
        public string QueuePosition { get; set; }
        public IEnumerable<Children> Childrens { get; set; } = new List<Children>();
        public IEnumerable<Group> Groups { get; set; } = new List<Group>();
    }

}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class EatingHistory
    {
        [Key]
        public Guid Id { get; set; }
        public string Meal { get; set; }
        public string Drink { get; set; }
        public string Dessert { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Absence
    {
        [Key]
        public Guid Id { get; set; }
        public DateTime Date { get; set; }
        public string reason { get; set; }
    }
}
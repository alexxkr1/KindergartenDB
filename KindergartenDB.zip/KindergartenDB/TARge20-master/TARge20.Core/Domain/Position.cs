﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Position
    {
        [Key]
        public Guid Id { get; set; }
        public string PositionType { get; set; }
        public string PositionName { get; set; }

    }
}
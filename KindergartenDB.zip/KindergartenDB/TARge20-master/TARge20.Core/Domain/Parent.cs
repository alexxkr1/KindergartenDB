﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Parent
    {
        [Key]
        public Guid Id { get; set; }
        public string MumName { get; set; }
        public string DadName { get; set; }
        public int MumPhone { get; set; }
        public int DadPhone { get; set; }

    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Kitchen
    {
        [Key]
        public Guid Id { get; set; }

        public IEnumerable<Cook> Cooks { get; set; } = new List<Cook>();
        public IEnumerable<Menu> Menus { get; set; } = new List<Menu>();
    }
}


